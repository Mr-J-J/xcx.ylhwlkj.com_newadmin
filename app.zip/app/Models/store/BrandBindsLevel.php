<?php

namespace App\Models\store;


use Illuminate\Database\Eloquent\Model;

class BrandBindsLevel extends Model
{
    public $incrementing = false;
    protected $table = 'brand_level';
    
}
