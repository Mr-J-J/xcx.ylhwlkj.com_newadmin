<?php

namespace App\ApiModels\Wangpiao;

use Illuminate\Database\Eloquent\Model;

class CinemaLine extends Model
{
    //
}
