<?php

namespace App\Admin\Controllers;



use App\Models\Store;
use App\MallModels\Order;
use App\Models\StoreInfo;
use App\Models\UserOrder;
use App\MallModels\Stores;
use App\MallModels\Product;
use App\Models\TicketUser;
use Illuminate\Support\Arr;
use App\CardModels\RsStores;
use App\MallModels\Category;
use Illuminate\Http\Request;
use App\CardModels\CardOrder;
use Encore\Admin\Widgets\Form;
use Encore\Admin\Facades\Admin;
use App\Models\store\StoreLevel;
use Encore\Admin\Layout\Content;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

class HomeController extends Controller
{

    public function index(Content $content)
    {
        $content->title('主页');
        if(!Auth::guard('admin')->user()->isAdministrator()){
            return $this->storeIndex($content);
        }
        return $content->body('');
    }

    /**
     * 商家主页
     *
     * @param Content $content
     * @return void
     */
    public function storeIndex(Content $content)
    {
        $comId = Store::getStoreId();
        $store = Store::where('id',$comId)->first();
        $data['balance'] = $store->balance;
        $data['cash_balance'] = $store->cash_balance;
        $today = date('Y-m-d');
        //今日支出     
        $data['todayZhichu'] = \App\Models\store\StoreBalanceDetail::where('com_id',$comId)->whereDate('created_at',date('Y-m-d'))->where('type',2)->sum('money');
        //昨日支出
        $yesterday = strtotime('-1 day');
        $data['yesterdayZhichu'] = \App\Models\store\StoreBalanceDetail::where('com_id',$comId)->whereDate('created_at',date('Y-m-d',$yesterday))->where('type',2)->sum('money');
        //本月支出
        $data['monthZhichu'] = \App\Models\store\StoreBalanceDetail::where('com_id',$comId)->whereYear('created_at',date('Y'))->whereMonth('created_at',date('m'))->where('type',2)->sum('money');

        $data['totalOrderNum'] = \App\Models\Tongji::where('com_id',$comId)->where('type',2)->sum('number');

        $data['cardNumber'] =  \App\Models\Tongji::where('com_id',$comId)->where('type',1)->whereDate('created_at',$today)->value('number'); //今日制卡
        return $content->body(view('custom.admin.statistics',$data));
    }

    
    public function region(Request $req){
        $q = $req->input('q','');
        $list = [];        
        $list = \App\Models\Region::where('city_level','>',1)
                            ->where('city_name','like',"%{$q}%")
                            ->orderBy('city_code')
                            ->paginate(5,['city_code as id','city_name as text']);
        return response()->json($list);
    }

    public function selectCity(Request $req,$level = 1){
        $q = $req->input('q');        
        $regionsList = \App\Models\Region::getRegions((int)$q,(int)$level,['city_code as id','city_name as text']);
        return response()->json($regionsList);
    }
}
