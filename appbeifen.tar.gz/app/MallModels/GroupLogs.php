<?php

namespace App\MallModels;

use Illuminate\Database\Eloquent\Model;

class GroupLogs extends Model
{
    protected $table = 'mall_group_logs';

    protected $guarded = [];
    protected $fillable = [];
}
