<?php

namespace App\Models;

use App\Support\Helpers;
use Illuminate\Database\Eloquent\Model;

class Carousel extends Model
{
    protected $hidden = ['created_at','updated_at'];

    static function getList(int $positionId = 0,$limit = 5){
        $list = self::where('category_id',$positionId)->orderBy('sort')->take($limit)->get(['id','image','url']);  
        foreach($list as $item){
            $item->image = Helpers::formatPath($item->image,'admin');
        }
        return $list;
    }
}
