<?php

namespace App\Models;

use App\Support\MApi;
use Overtrue\Pinyin\Pinyin;
use App\Support\Helpers;
use Illuminate\Database\Eloquent\Model;
/**
 * 城市列表
 */
class Region extends Model
{
    
    protected $primaryKey = 'city_code';
    
    protected $guarded  = [];

    protected $hidden = ['created_at','updated_at'];

    
}
