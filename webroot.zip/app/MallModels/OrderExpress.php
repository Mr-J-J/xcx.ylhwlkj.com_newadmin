<?php

namespace App\MallModels;

use Illuminate\Database\Eloquent\Model;

class OrderExpress extends Model
{
    protected $table = 'mall_orders_express';

    /**
     * 创建发货单 
     *
     * @param Order $order
     * @return OrderExpress
     */
    static function createExpress(Order $order){
        $oe = new self;
        $oe->id =  $order->id;
        $oe->express_flag = $oe->express_sn = $oe->express_name = '';
        $oe->area = $order->area;
        $oe->address = $order->address;
        $oe->mobile = $order->mobile;
        $oe->user_remark = $order->user_remark;
        $oe->order_status = 10;
        $oe->save();
        return $oe;
    }
}
