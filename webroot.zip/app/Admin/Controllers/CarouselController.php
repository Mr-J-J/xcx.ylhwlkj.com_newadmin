<?php

namespace App\Admin\Controllers;

use App\MallModels\Activite;
use Encore\Admin\Form;
use Encore\Admin\Grid;
use Encore\Admin\Show;
use App\Models\Carousel;
use App\MallModels\Category;
use Encore\Admin\Controllers\AdminController;
use Illuminate\Support\Arr;

class CarouselController extends AdminController
{
    /**
     * Title for current resource.
     *
     * @var string
     */
    protected $title = '轮播图';

    /**
     * Make a grid builder.
     *
     * @return Grid
     */
    protected function grid()
    {
        $grid = new Grid(new Carousel());
        
        $category = $this->getCategory();
        // $category = [];
        $grid->filter(function($filter) use ($category){
            $filter->expand();
            $filter->disableIdFilter();
            $filter->equal('category_id','分类')->select($category);
        });
        $grid->column('id', __('编号'));
        $grid->column('image', __('图片'))->image('',300,130);
        $grid->column('category_id','类别')->display(function($categoryId) use ($category){
            return $category[$categoryId] ?? '无';
        });
        $grid->column('title', __('备注'));
        $grid->column('url', __('跳转地址'));
        $grid->column('sort', __('排序'));

        return $grid;
    }

    /**
     * Make a show builder.
     *
     * @param mixed $id
     * @return Show
     */
    protected function detail($id)
    {
        $show = new Show(Carousel::findOrFail($id));

        $show->field('image', __('图片'));
        $show->field('id', __('编号'));
        $show->field('title', __('备注'));
        $show->field('url', __('跳转地址'));
        $show->field('sort', __('排序'));
        $show->field('created_at', __('添加时间'));

        return $show;
    }

    /**
     * Make a form builder.
     *
     * @return Form
     */
    protected function form()
    {
        $form = new Form(new Carousel());        
        $form->select('category_id','所属分类')->options($this->getCategory())->help('分类代表banner图展示的位置');
        $form->text('title', __('备注'));
        $form->image('image', __('图片'))->move('banner')->uniqueName();
        $form->url('url', __('跳转地址'));
        $form->number('sort', __('排序'))->default(1);

        return $form;
    }

    protected function getCategory(){
        $category = (array)Category::getFirstList();
        array_unshift($category,['title'=>'默认分类[首页]','id'=>0]);
        $activity = Activite::getList()->map(function($d){
                        return $d->only(['id','title']);
                    })->toArray();
        array_push($category,...$activity);        
        return Arr::pluck($category,'title','id');
    }
}
