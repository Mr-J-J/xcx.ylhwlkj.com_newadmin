<?php

namespace App\Admin\Controllers\Card;

use App\CardModels\Cards;
use Encore\Admin\Controllers\AdminController;
use Encore\Admin\Form;
use Encore\Admin\Grid;
use Encore\Admin\Show;


class CardController extends AdminController
{
    
    /**
     * Title for current resource.
     *
     * @var string
     */
    protected $title = '影旅卡管理';

    /**
     * Make a grid builder.
     *
     * @return Grid
     */
    protected function grid()
    {
        $grid = new Grid(new Cards());
        $grid->disableFilter();
        $grid->actions(function($action){
            $action->disableView();
            $action->disableDelete();
        });
        $grid->column('id','ID');
        $grid->column('title', '标题');
        $grid->column('short_title', '副标题');
        $grid->column('image', '背景大图')->image('',120,60);
        $grid->column('list_image', '列表图')->image('',60);
        $grid->column('index_image', '首页展示图')->image('',120,60);
        $grid->column('price', '成本价');
        $grid->column('market_price', '划线价');
        $grid->column('card_money', '卡余额');
        $grid->column('state', '状态')->using(['已停用','已启用'])->label(['default','success']);
        return $grid;
    }

    /**
     * Make a show builder.
     *
     * @param mixed $id
     * @return Show
     */
    protected function detail($id)
    {
        $show = new Show(Cards::findOrFail($id));

        $show->field('id', __('Id'));
        $show->field('title', __('Title'));
        $show->field('short_title', __('Short title'));
        $show->field('image', __('Image'));
        $show->field('list_image', __('List image'));
        $show->field('index_image', __('Index image'));
        $show->field('price', __('Price'));
        $show->field('card_money', __('Card money'));
        $show->field('market_price', __('Market price'));
        $show->field('sort', __('Sort'));
        $show->field('created_at', __('Created at'));
        $show->field('updated_at', __('Updated at'));

        return $show;
    }

    /**
     * Make a form builder.
     *
     * @return Form
     */
    protected function form()
    {
        $form = new Form(new Cards());

        $form->text('title', '标题');
        $form->text('short_title', '副标题');
        $form->decimal('price','成本价')->default(0.00);
        $form->decimal('card_money', '卡余额')->default(0.00);
        $form->decimal('market_price', '划线价')->default(0.00);
        $form->image('image', '背景大图')->help('建议尺寸600 x 330像素，大小900K以内');
        $form->image('list_image','列表图')->help('建议尺寸200 x 200像素，大小900K以内');;
        $form->image('index_image', '首页展示图')->help('建议尺寸300 x 178像素，大小900K以内');
        // $form->number('sort', __('Sort'));
        $form->radio('state','卡片状态')->options(['停用','启用'])->default(1);

        return $form;
    }
}
