<?php
namespace App\Support;
use GuzzleHttp\Client;
use Overtrue\Pinyin\Pinyin;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Cache;
use GuzzleHttp\Exception\ClientException;
use GuzzleHttp\Exception\RequestException;
use Monolog\Logger;
use Monolog\Handler\StreamHandler;

class WpApi
{

    // const BASEURI = 'http://test.api.wangpiao.com';
    // const USER = 'test1';
    // const SECRET = '4vYwB5csWrdLbFkG';
    
    const BASEURI = 'http://channel.api.wangpiao.com:88/2.0/Default.aspx';
    const USER = 'WP_YLHWPWAPI';
    const SECRET = 'NLzu8nX5eNXAaEkY';
    const DELAY_TIME = 20;//20分钟

    public static function __callStatic($method, $arguments){     
        
        
        try {
            $result =  call_user_func_array(array('self', $method), $arguments);
        } catch (\Throwable $th) {
           $result =  call_user_func(array('self', $method));
        }
        
        return $result;
    }

    /**
     * 座位翻译
     *
     * @param string $sid
     * @return void
     */
    static function unLockSeat(string $sid){
        $data = array(
            'SID' => $sid,
        );
        return self::commonRequest('Sell_UnLockSeat',$data);
    }
    /**
     * 锁座
     *
     * @param [type] $params
     * @return void
     */
    static function lockSeat($params){
        $data = array(
            'UserID' => $params['user_id'],
            'ShowIndex' => $params['paiqi_id'],
            'CinemaID' => $params['cinema_id'],
            'SeatInfo' => $params['seat_ids'],
        );
        
        if(!empty($params['mobile'])){
            $data['Mobile'] = $params['mobile'];
        }
        if(!empty($params['contacts'])){
            $data['Contacts'] = $params['contacts'];
        }

        // $param = self::getSignParam('Sell_LockSeatSafe',$data);
        $param = self::getSignParam('Sell_LockSeat_V2',$data);
        $param = array_merge($param,$data);
        $response = self::request_post($param);
        self::logger('锁座!; request params :'.json_encode($params,256).',result:'.json_encode($response,256));
        return $response;
        // return self::commonRequest('Sell_LockSeatSafe',$data);
    }
    
    /**
     * 用于验证某个影院的某个场次是否有效，规避因影讯改场且同步更新不及时导致的不合理锁座请求
     * 注：需要影院编号、放映流水号、放映日期同时满足。* 
     *
     * @param [type] $cinema_id
     * @param * $date
     * @param [type] $showIndex
     * @return void
     */
    static function FilmShowCheck($cinema_id,$date,$showIndex){
        $data = array(
            'CinemaID' => $cinema_id,
            'Date' => $date,
            'ShowIndex' => $showIndex,
        );
        return self::commonRequest('Base_FilmShowCheck',$data);
    }

    /**
     * 影片信息查询接口，用于查询影片信息。
     *
     * @param [type] $film_id
     * @return void
     */
    static function getFilmInfo($film_id){
        $data = array(
            'FilmID' => $film_id,
        );
        return self::commonRequest('Base_FilmHE',$data);
    }
    
    /**
     * 查询影院指定日期的放映计划
     *
     * @param [type] $cinema_id
     * @param [type] $date
     * @param string $film_id
     * @return void
     */
    static function getFilmShowByDate($cinema_id,$date,$film_id = ''){
        $data = array(
            'CinemaID' => $cinema_id,
            'Date'     => $date,
        );
        
        if($film_id != ''){
            $data['FilmID'] = $film_id;
        }
        return self::commonRequest('Base_FilmShow',$data);
    }

    /**
     * 查询影院指定三天以上的日期的放映计划，不填日期默认为所有三天以上的场次
     *
     * @param [type] $cinema_id
     * @param [type] $date yyyy-MM-dd HH:mm:ss
     * @param string $film_id
     * @return void
     */
    static function getPreFilmShow($cinema_id,$date,$film_id = ''){
        $data = array(
            'CinemaID' => $cinema_id,
            'Date'     => $date,
        );
        
        if($film_id != ''){
            $data['FilmID'] = $film_id;
        }
        return self::commonRequest('Base_PreFilmShow',$data);
    }


    

    /**
     * 座位信息查询接口，用于查询影厅的座位信息。
     *
     * 返回示例 0 => array:2 [
        *       "SeatID" => "768"
        *      "Status" => "N"
        *   ]
     * @param [type] $showIndex
     * @param [type] $cinema_id
     * @return void
     */
    static function getSellSeatInfo($showIndex,$cinema_id){
        $data = array(
            'CinemaID' => $cinema_id,
            'ShowIndex'     => $showIndex,
        );
        
        return self::commonRequest('Base_SellSeat_V2',$data);//Base_SellSeat
    }

    /**
     * 座位信息查询接口，用于【按影厅编号】查询影厅的座位信息。
     * 0 => array:8 [
      *      "SeatIndex" => 78077696   座位唯一标识
      *      "SeatID" => "778"      座位编码
      *      "Name" => "1:1"        座位名称,如 1:2，表示 1 排 2 座
      *      "RowID" => 29    行坐标
      *      "ColumnID" => 548   列坐标
      *      "LoveFlag" => 0   情侣座标识 0：普通座位 1：情侣座首座位标记 2：情侣座第二座位标记
      *      "Status" => "N"  座位状态 Y 表示座位完好,可以售票;N 表示座位损坏,不允许售票
      *      "SectionID" => "1"   
      *  ]     
     * @param [type] $hallId
     * @param [type] $cinema_id
     * @return void
     */
    static function getSeatByHallId($hallId,$cinema_id){
        $data = array(
            'HallID' => $hallId,
            'CinemaID'  => $cinema_id
        );

        return self::commonRequest('Base_HallSeat',$data);
    }
    /**
     * 座位信息查询接口，用于【按场次号】查询影厅的座位信息。
     *
     * @param [type] $showIndex
     * @param [type] $cinema_id
     * @return void
     */
    static function getSeatByShowIndex($showIndex,$cinema_id){
        $data = array(
            'ShowIndex' => $showIndex,
            'CinemaID'  => $cinema_id
        );

        return self::commonRequest('Base_Seat',$data);
    }

    /**
     * 全国影讯查询 — Base_FilmView
     *
     * @param [type] $city_id
     * @param string $cinema_id
     * @return void
     */
    static function getFilmViewList($city_id,$cinema_id = ''){
        
        $data = array(
            'CityID' => $city_id
        );
        
        if($cinema_id != ''){
            $data['CinemaID'] = $cinema_id;
        }
        return self::commonRequest('Base_FilmView',$data);
    }
    
    /**
     * 即将上映的影片信息查询
     *
     * @param string $date  :yyyy-MM-dd
     * @param string $cinema_id
     * @return void
     */
    static function getPlanFilm($date = '',$cinema_id = ''){
        $data = array();
        if($date != ''){
            $data['Date'] = $date ;
        }
        if($cinema_id != ''){
            $data['CinemaID'] = $cinema_id;
        }
        return self::commonRequest('Base_FilmIM',$data);
    }

    /**
     * 正在上映的影片信息查询
     *
     * @param [type] $city_id
     * @param string $date 日期时间转换后的 字 符 型 格 式 :yyyy-MM-dd HH:mm:ss
     * @param string $film_id
     * @return void
     */
    static function getCurrentFilm($city_id,$date = '',$cinema_id = ''){
        $data = array(
            'CityID'=>$city_id,
        );
        if($date != ''){
            $data['Date'] = $date ;
        }
        if($cinema_id != ''){
            $data['CinemaID'] = $cinema_id;
        }
        
        return self::commonRequest('Base_Film',$data);
    }

    /**
     * 影厅信息查询接口，用于查询影厅信息。
     *
     * @return void
     */
    static function getCinemaHall($cinema_id){
        $data = array(
            'CinemaID'=>$cinema_id
        );
        return self::commonRequest('Base_Hall',$data);
    }

    /**
     * 根据城市,(影片),日期查询有放映计划的影院
     *
     * @param [type] $city_id
     * @param [type] $date  日期时间转换后的字符型 格 式 :yyyy-MM-ddHH:mm:ss
     * @param [type] $film_id
     * @return void
     */
    static function getCinemaQueryList($city_id,$date,$film_id = ''){
        $data = array(
            'CityID'=>$city_id,
            'Date' =>$date,
        );
        if($film_id != ''){
            $data['FilmID'] = $film_id;
        }
        return self::commonRequest('Base_CinemaQuery',$data);
    }
    /**
     * 影院查询接口，用于查询影院信息
     *
     * @param [type] $city_code
     * @return void
     */
    static function getCinemaList(){
        return self::commonRequest('Base_Cinema');
    }

    /**
     * 用于查询院线。
     *
     * @return void
     */
    static function getCinemaLineList(){
        return self::commonRequest('Base_CinemaLine');
    }
 

    /**
     * 同步地铁
     *
     * @return void
     */
    static function getSubWay(){
        return self::commonRequest('Base_SubWay');
    }
    /**
     * 同步商圈
     *
     * @return void
     */
    static function getTradingArea(){
        return self::commonRequest('Base_TradingArea');
    }

    /**
     * 城市区域查询
     *
     * @return void
     */
    static function getCityDistrict(){
        return self::commonRequest('Base_District');
    }
    /**
     * 获取已有业务城市查询
     *
     * @return void
     */
    static function getCityBillList(){
        return self::commonRequest('Base_CityBll');        
    }    
    /**
     * 取得城市列表
     *
     * @return void
     */
    static function getCityList(){
        return self::commonRequest('Base_City');
    }

    /**
     * 公共请求
     *
     * @param [type] $target
     * @return void
     */
    static function commonRequest($target,$data = []){
        $param = self::getSignParam($target,$data);
        if(!empty($data)){
            $param = array_merge($param,$data);
        }
        if(!empty($param['Date'])){
            if(strtotime(date('Y-m-d'))> strtotime($param['Date'])){
                return false;
            }
        }
        $response = self::request_post($param);
        if($response === false){
            return array();
        }
        try {
            if($response['ErrNo'] == 11){
                // self::logger('获取数据失败!; request params :'.json_encode($param,256).',result:'.json_encode($response,256));
                $response = retry(2,function()use ($param){
                        $logger = '再次尝试请求数据:';
                        $return = self::request_post($param);
                        if(empty($return['Data'])){
                            // self::logger($logger.'请求失败');
                            throw new \Exception('别试了..');
                        }
                        // self::logger($logger.'请求成功');
                        
                        return $return;
                    },220);
            }
        } catch (\Exception $e) {
            self::logger('获取数据失败:'.$e->getMessage());
            return array();
        }
        $result = $response;
        $result['Data'] = [];
        // self::logger(json_encode(compact('param','target','result')).' 获取'.count($response['Data']).'条数据;');
        return $response['Data'];
    }
     

    /**
     * post请求
     *
     * @param [type] $uri
     * @param array $data
     * @return void
     */
    private static function request_post($data=[]){
        $request = new Client;                
        $response = $request->post(self::BASEURI,[
            'form_params'=>$data,
            'timeout' => 10000,
            'connect_timeout' => 10000,
            'read_timeout' => 10000
        ]);
        
        $result = json_decode((string)$response->getBody(),true);
        if($result['ErrNo'] != 0){
            return false;
        }
        if(empty($result['Data'])){
            
            return ['ErrNo'=>11,'Data'=>[]];
        }
        return $result;
    }


    /**
     * 签名
     *
     * @param string $target
     * @param array $param
     * @return void
     */
    private static function getSignParam($target = '',$param = []){        
        $query['Target'] = $target;
        $query['UserName'] = self::USER;
        $Sign = md5($target.self::USER.self::SECRET);      
        
        if(!empty($param)){
            $param = array_merge($param,$query);
            ksort($param);
            $values = array_values($param);
            $Sign = md5(join('',$values).self::SECRET);            
        }
        $query['Sign'] = $Sign;
        
        return $query;
    }
    
    
    public static function logger($logtxt){
        try {
            $path = storage_path('logs/request-'.date('Y-m-d').'.log');
        $log = new Logger('apirequest');
        $log->pushHandler(new StreamHandler($path, Logger::INFO));
        $log->info(json_encode(request()->ip().$logtxt,JSON_UNESCAPED_UNICODE));
        } catch (\Exception $e) {
            @unlink(storage_path('logs/request-'.date('Y-m-d').'.log'));
        }
    }


}