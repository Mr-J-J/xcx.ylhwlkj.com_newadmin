<?php
namespace App\Support;
use GuzzleHttp\Client;



class PAPI
{

    
    static function download($id = 1, $size = 100){
        
        $url = "http://www.hblingxing.com/prod-api/collect/lib/getGoodsList?id={$id}&pageNum=1&pageSize={$size}&type=1";

        return self::request_post($url);
    }

    /**
     * post请求
     *
     * @param [type] $uri
     * @param array $data
     * @return void
     */
    private static function request_post($url,$data=[]){
        $request = new Client;        
        $response = $request->get($url,[
            'form_params'=>$data,
            'timeout' => 10000,
            'connect_timeout' => 10000,
            'read_timeout' => 10000
        ],array(
                "Authorization"=>"eyJhbGciOiJIUzI1NiJ9.eyJsb2dpbl91c2VyX2tleSI6IjFmNDRkNDg3LTdkNDQtNGFiZi1iMTc0LWU4NTNmMmU4NmU4YiJ9.cFLpA0-SJmc_Do2vGIXf1FfvOeED78tZoD_Y_QXNfQk",
                "Cookie"=>"Admin-Token=eyJhbGciOiJIUzI1NiJ9.eyJsb2dpbl91c2VyX2tleSI6IjFmNDRkNDg3LTdkNDQtNGFiZi1iMTc0LWU4NTNmMmU4NmU4YiJ9.cFLpA0-SJmc_Do2vGIXf1FfvOeED78tZoD_Y_QXNfQk",
                "Host"=>"www.hblingxing.com",
                "Referer"=>"http://www.hblingxing.com/admin/commod/brandLib/1?name=%E5%8A%9E%E5%85%AC%E7%94%A8%E7%BA%B8"
            
        ));
        
        $result = json_decode((string)$response->getBody(),true);
        
        return $result;
    }


    

}