<div class="list-group sidebar-menu">
  <a href="/stores" class="list-group-item list-group-item-action">首页</a>
  <a href="/stores/settle" class="list-group-item list-group-item-action">结算管理</a>
  <a href="/stores/account" class="list-group-item list-group-item-action">分成明细</a>
  {{-- <a href="/stores/member" class="list-group-item list-group-item-action">用户管理</a> --}}
  <a href="/stores/order" class="list-group-item list-group-item-action">影旅卡订单</a>
  <a href="/stores/card" class="list-group-item list-group-item-action">影旅卡列表</a>
  <a href="/stores/profile" class="list-group-item list-group-item-action">分销商资料</a>
</div>
