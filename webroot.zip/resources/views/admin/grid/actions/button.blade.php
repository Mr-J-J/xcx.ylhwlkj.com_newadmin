
@foreach($default as $action)
    {!! $action->render() !!}
@endforeach

@if(!empty($custom))
    @foreach($custom as $action)
    {!! $action->render() !!}
    @endforeach
@endif
@yield('child')
